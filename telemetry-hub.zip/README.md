# TelemetryHub — Real-Time Telemetry Streaming & Data Lakehouse Engine

A production-grade, real-time monitoring platform for high-throughput telemetry pipelines. It simulates a complete **AWS / Apache Kafka / SQL Data Lakehouse** observability stack — live metric streaming, Kafka topic inspection, Iceberg/Delta Lake table cataloging, multi-region cluster topology, and threshold-based alerting — all in a single-page React application with zero backend dependencies.

> **Built by [Sejal Gohil](https://github.com/sejal-gohil09)**

---

## Business Problem

Modern data-driven organizations operate **telemetry pipelines** that ingest millions of events per second from IoT sensors, user activity trackers, application logs, and distributed traces. Operating these pipelines at scale creates several pain points:

| Pain Point | Impact |
|---|---|
| **No unified visibility** across Kafka topics, lakehouse tables, and cluster nodes | Ops teams switch between 5+ tools (Grafana, Confluent Console, AWS Console, Spark UI, Iceberg REST) just to assess system health |
| **Consumer lag goes unnoticed** until downstream services degrade | A topic with 8,900+ messages in lag silently starves downstream consumers |
| **No schema visibility** for lakehouse tables | Engineers query tables blind — no easy way to see partition keys, column types, or compaction status |
| **Alerts are reactive, not proactive** | Threshold breaches are detected post-incident when a customer reports an outage |
| **Multi-region blind spots** | A degraded broker in us-west-2 goes unnoticed by teams monitoring only us-east-1 |

## Solution

TelemetryHub consolidates the entire observability surface into a single dashboard with six purpose-built views:

1. **Dashboard Overview** — Real-time KPI cards (ingest rate, throughput, P99 latency, error rate, CPU, memory, storage, active consumers), live area charts, circular gauges, topic throughput bar chart, and cluster health summary
2. **Event Streams** — Kafka-style topic browser with live event feed, per-topic filtering, full-text search, event payload inspection, and pause/resume controls
3. **Data Lakehouse** — Iceberg/Delta/Hudi table catalog with full schema definitions, partition key markers, query performance metrics, and compaction status
4. **Infrastructure Topology** — Multi-region cluster map showing 12 nodes (brokers, Spark workers, coordinators, storage gateways, ingest gateways) with live CPU/memory bars and health status
5. **Alerts** — Threshold-driven alert stream with severity levels (critical/warning/info), acknowledgment workflow, and clear-all
6. **Settings** — Cluster configuration (retention, replication factor, compaction interval), auto-scaling toggles, notification channels, and security posture

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        BROWSER (Single-Page App)                     │
│                                                                      │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────┐ │
│  │ Overview  │  │  Event   │  │ Lakehouse│  │ Topology │  │ Alerts│ │
│  │ Dashboard │  │ Streams  │  │  Explorer│  │   Map    │  │ Panel │ │
│  └─────┬─────┘  └─────┬────┘  └─────┬────┘  └─────┬────┘  └───┬───┘ │
│        │              │             │              │           │     │
│        └──────────────┴─────────────┴──────────────┴───────────┘     │
│                              │                                       │
│                    ┌─────────┴─────────┐                             │
│                    │  Telemetry Engine   │  ← Random-walk simulation   │
│                    │  (React Hook)        │     generates live metrics, │
│                    └─────────────────────┘     events, alerts, nodes  │
│                              │                                       │
│                    ┌─────────┴─────────┐                             │
│                    │  SVG Chart Engine   │  ← Custom area, bar,        │
│                    │  (zero-dependency)  │     gauge, sparkline       │
│                    └─────────────────────┘                             │
└─────────────────────────────────────────────────────────────────────┘
```

### Simulated Data Pipeline (What This App Models)

```
 IoT Sensors          User Events         App Logs          Distributed Traces
     │                    │                  │                     │
     ▼                    ▼                  ▼                     ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     Ingest Gateways (us-east-1, us-west-2)           │
└──────────────────────────────┬──────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    Apache Kafka Cluster (3 Brokers)                  │
│                                                                      │
│  telemetry.iot.devices   events.user.activity   logs.application    │
│  metrics.system          traces.distributed     events.billing      │
│  telemetry.vehicle.fleet logs.audit.security                         │
│                                                                      │
│  8 topics · 76 partitions · RF=2-3 · retention 3d-365d              │
└──────────────────────────────┬──────────────────────────────────────┘
                               │
              ┌────────────────┼────────────────┐
              ▼                ▼                 ▼
     ┌─────────────┐  ┌──────────────┐  ┌──────────────┐
     │  Spark/Flink │  │  Stream      │  │  Consumers   │
     │  Workers    │  │  Processors  │  │  (37 active)  │
     └──────┬──────┘  └──────┬───────┘  └──────────────┘
            │                │
            ▼                ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    Data Lakehouse (S3 + Iceberg/Delta/Hudi)          │
│                                                                      │
│  fact_telemetry_events    fact_user_sessions     agg_throughput_hr  │
│  dim_devices              fact_audit_log        agg_error_summary   │
│                                                                      │
│  6 tables · 2,784 partitions · ~2.8 TB · 177K queries/day          │
└─────────────────────────────────────────────────────────────────────┘
```

### Tech Stack

| Layer | Technology | Why |
|---|---|---|
| **Framework** | React 18 + TypeScript 5 | Strict typing, hooks-based architecture |
| **Build Tool** | Vite 5 | Fast HMR, optimized production builds |
| **Styling** | Tailwind CSS 3 | Utility-first, consistent design system |
| **Icons** | Lucide React | Lightweight, tree-shakeable SVG icons |
| **Charts** | Custom SVG components | Zero chart-library dependency — full control over rendering |
| **State** | React hooks (useState/useEffect) | No external state management needed for simulation engine |
| **Fonts** | Inter + JetBrains Mono | Professional UI + monospace for data values |

### Key Design Decisions

- **Zero chart dependencies**: All charts (area, bar, gauge, sparkline) are hand-built SVG components. This keeps the bundle at ~228 KB (62 KB gzipped) and gives pixel-level control over animations and styling.
- **Random-walk simulation**: The telemetry engine uses bounded random-walk algorithms to generate realistic metric drift, event streams, and node health fluctuations. Each metric has independent volatility and threshold parameters.
- **1.5-second tick interval**: Balances visual liveliness with performance — metrics update smoothly without overwhelming the browser's render pipeline.
- **Client-side only**: The entire app runs in the browser with no backend calls. The simulation engine replaces a real Kafka/Spark/Iceberg backend, making it instantly deployable as a static site.

---

## Features

### Dashboard Overview
- 8 live KPI cards with trend indicators and embedded sparklines
- Real-time ingest throughput area chart (90-second rolling window)
- 4 circular gauges (CPU, memory, storage, P99 latency) with color-coded thresholds
- Topic throughput bar chart with lag-based color coding
- Cluster health summary (healthy / degraded / offline node counts)
- Recent events preview feed

### Event Streams
- 8 Kafka topics across 5 categories (telemetry, events, logs, metrics, traces)
- Live event feed with per-topic filtering and full-text search
- Event detail panel with full payload inspection (JSON), partition, offset, key, latency
- Pause/resume stream control
- Summary stats: total topics, throughput, consumer lag, partition count

### Data Lakehouse
- 6 tables across 3 formats (Apache Iceberg, Delta Lake, Apache Hudi)
- Full schema definitions with column types and partition key markers
- Per-table stats: row count, size, partition count, query volume, average query latency
- Query performance indicators with visual progress bars
- Compaction status tracking

### Infrastructure Topology
- 12 nodes across 2 AWS regions (us-east-1, us-west-2)
- 5 node types: brokers, Spark workers, coordinators, storage gateways, ingest gateways
- Live CPU/memory utilization bars per node
- Health status: healthy, degraded, down (with failover status)
- Node detail panel with health checks (heartbeat, disk, network I/O, replication)
- Type legend and region grouping

### Alerts
- Threshold-driven alert generation (warning and critical levels)
- Alert stream with severity badges, timestamps, and source attribution
- Acknowledge individual alerts or clear all
- Summary cards: active count, critical, warning, acknowledged

### Settings
- Stream configuration: retention period, replication factor, compaction interval
- Lakehouse engine format selection (Iceberg / Delta / Hudi)
- Auto-scaling toggle for consumer elasticity
- Notification channels: email and Slack integration toggles
- Security posture: TLS, SASL, at-rest encryption, audit logging

---

## Getting Started

### Prerequisites

- Node.js 18+ and npm

### Installation

```bash
# Clone the repository
git clone https://github.com/sejal-gohil09/telemetry-hub.git
cd telemetry-hub

# Install dependencies
npm install

# Start the development server
npm run dev
```

The app will be available at `http://localhost:5173`.

### Build for Production

```bash
# Create an optimized production build
npm run build

# Preview the production build locally
npm run preview
```

The built files will be in the `dist/` directory, ready to deploy to any static hosting provider (GitHub Pages, Netlify, Vercel, S3, etc.).

### Available Scripts

| Script | Description |
|---|---|
| `npm run dev` | Start Vite dev server with HMR |
| `npm run build` | Production build to `dist/` |
| `npm run preview` | Preview the production build locally |
| `npm run typecheck` | TypeScript type checking (no emit) |
| `npm run lint` | ESLint with React hooks and refresh rules |

---

## Project Structure

```
telemetry-hub/
├── public/
│   └── favicon.svg              # Custom SVG favicon
├── src/
│   ├── components/
│   │   ├── Charts.tsx           # SVG chart components (Area, Bar, Gauge, Sparkline)
│   │   ├── Sidebar.tsx          # Navigation sidebar with live ingest indicator
│   │   └── Topbar.tsx           # Top bar with search, clock, streaming status
│   ├── hooks/
│   │   └── useTelemetryEngine.ts # Real-time simulation engine hook
│   ├── lib/
│   │   └── telemetry.ts         # Data models, simulation logic, seed data
│   ├── views/
│   │   ├── Overview.tsx         # Dashboard with metrics, charts, gauges
│   │   ├── EventStreams.tsx     # Kafka topic browser + live event feed
│   │   ├── Lakehouse.tsx        # Iceberg/Delta/Hudi table catalog
│   │   ├── Topology.tsx         # Multi-region infrastructure map
│   │   ├── Alerts.tsx           # Alert stream with acknowledgment
│   │   └── Settings.tsx         # Cluster and notification configuration
│   ├── App.tsx                  # Root component with view routing
│   ├── main.tsx                 # React entry point
│   └── index.css                # Tailwind + custom styles
├── .env.example                 # Environment variable template
├── LICENSE                      # MIT License
└── README.md                    # This file
```

---

## Deployment

### GitHub Pages

```bash
# Build the project
npm run build

# Deploy the dist/ folder to GitHub Pages
# Or use the gh-pages package:
npm install -D gh-pages
npx gh-pages -d dist
```

### Netlify / Vercel

1. Connect the GitHub repository to Netlify or Vercel
2. Set build command: `npm run build`
3. Set publish directory: `dist`
4. Deploy — no environment variables required

---

## License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

---

## Author

**Sejal Gohil** — [GitHub](https://github.com/sejal-gohil09)

---

## Acknowledgments

This project simulates the architecture and operational patterns of real-world telemetry platforms used by companies operating large-scale IoT, streaming, and data lakehouse infrastructure. The data models, Kafka topic structures, Iceberg table schemas, and alerting patterns reflect industry-standard practices from the Apache Kafka, Apache Iceberg, Delta Lake, and Apache Hudi ecosystems.
