import { useEffect, useRef, useState, useCallback } from 'react';
import {
  createInitialMetrics,
  tickMetrics,
  generateEvent,
  generateAlerts,
  tickNodes,
  type MetricSeries,
  type StreamEvent,
  type AlertItem,
  type NodeInfo,
} from '@/lib/telemetry';

export function useTelemetryEngine(intervalMs = 1500) {
  const [metrics, setMetrics] = useState<MetricSeries[]>(() => {
    const initial = createInitialMetrics();
    return initial.map((m) => ({ ...m, history: [m.value] }));
  });
  const [events, setEvents] = useState<StreamEvent[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [nodes, setNodes] = useState<NodeInfo[]>(() => tickNodes([]));

  const metricsRef = useRef(metrics);
  metricsRef.current = metrics;

  useEffect(() => {
    const tick = setInterval(() => {
      setMetrics((prev) => tickMetrics(prev));
      const newEvent = generateEvent();
      setEvents((prev) => [newEvent, ...prev].slice(0, 80));
      setNodes((prev) => (prev.length === 0 ? tickNodes(prev) : tickNodes(prev)));

      const newAlerts = generateAlerts(metricsRef.current);
      if (newAlerts.length > 0) {
        setAlerts((prev) => {
          const existing = new Set(prev.map((a) => a.id.split('-').slice(0, 2).join('-')));
          const fresh = newAlerts.filter((a) => {
            const key = a.id.split('-').slice(0, 2).join('-');
            return !existing.has(key);
          });
          return [...fresh, ...prev].slice(0, 50);
        });
      }
    }, intervalMs);

    return () => clearInterval(tick);
  }, [intervalMs]);

  const acknowledgeAlert = useCallback((id: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, acknowledged: true } : a))
    );
  }, []);

  const clearAlerts = useCallback(() => setAlerts([]), []);

  return { metrics, events, alerts, nodes, acknowledgeAlert, clearAlerts };
}
