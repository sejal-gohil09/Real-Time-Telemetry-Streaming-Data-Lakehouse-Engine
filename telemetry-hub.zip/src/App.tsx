import { useState } from 'react';
import { Sidebar, type ViewKey } from '@/components/Sidebar';
import { Topbar } from '@/components/Topbar';
import { Overview } from '@/views/Overview';
import { EventStreams } from '@/views/EventStreams';
import { Lakehouse } from '@/views/Lakehouse';
import { Topology } from '@/views/Topology';
import { Alerts } from '@/views/Alerts';
import { Settings } from '@/views/Settings';
import { useTelemetryEngine } from '@/hooks/useTelemetryEngine';

const VIEW_META: Record<ViewKey, { title: string; subtitle: string }> = {
  overview: { title: 'Dashboard Overview', subtitle: 'Real-time telemetry streaming and data lakehouse monitoring' },
  streams: { title: 'Event Streams', subtitle: 'Live Kafka topic consumer and event inspection' },
  lakehouse: { title: 'Data Lakehouse', subtitle: 'Apache Iceberg / Delta Lake table catalog and schema explorer' },
  topology: { title: 'Infrastructure Topology', subtitle: 'Cluster node health across regions and availability zones' },
  alerts: { title: 'Alerts & Notifications', subtitle: 'Active alerts, threshold breaches, and acknowledgment history' },
  settings: { title: 'Settings', subtitle: 'Cluster configuration, retention, scaling, and notification preferences' },
};

function App() {
  const [view, setView] = useState<ViewKey>('overview');
  const { metrics, events, alerts, nodes, acknowledgeAlert, clearAlerts } = useTelemetryEngine(1500);

  const activeAlerts = alerts.filter((a) => !a.acknowledged).length;
  const ingestRate = metrics.find((m) => m.key === 'ingestRate')?.value ?? 0;
  const meta = VIEW_META[view];

  return (
    <div className="min-h-screen bg-slate-950 flex">
      <Sidebar active={view} onNavigate={setView} alertCount={activeAlerts} ingestRate={ingestRate} />
      <main className="flex-1 min-w-0 flex flex-col">
        <Topbar title={meta.title} subtitle={meta.subtitle} />
        <div className="flex-1 overflow-y-auto">
          {view === 'overview' && <Overview metrics={metrics} events={events} alerts={alerts} nodes={nodes} />}
          {view === 'streams' && <EventStreams events={events} />}
          {view === 'lakehouse' && <Lakehouse />}
          {view === 'topology' && <Topology nodes={nodes} />}
          {view === 'alerts' && <Alerts alerts={alerts} onAcknowledge={acknowledgeAlert} onClear={clearAlerts} />}
          {view === 'settings' && <Settings />}
        </div>
      </main>
    </div>
  );
}

export default App;
